import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [

];

@NgModule({
  imports: [RouterModule.forRoot(routes),{
    preloadingStrategy: QuickLinkStragey 
  }],
  exports: [RouterModule]
})
export class AppRoutingModule { }
