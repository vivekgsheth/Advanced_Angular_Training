import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MyLibModule } from 'djpadmaroad-lib';
import { HxaLib1Module } from 'hxa-lib1';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MyLibModule,
    HxaLib1Module
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
