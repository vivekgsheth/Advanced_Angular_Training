/*
 * Public API Surface of hxa-lib1
 */

export * from './lib/hxa-lib1.service';
export * from './lib/hxa-lib1.component';
export * from './lib/hxa-lib1.module';
