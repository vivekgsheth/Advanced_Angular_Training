import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-hxa-lib1',
  template: `
    <h1>
      hxa library works!
    </h1>
  `,
  styles: [
  ]
})
export class HxaLib1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
