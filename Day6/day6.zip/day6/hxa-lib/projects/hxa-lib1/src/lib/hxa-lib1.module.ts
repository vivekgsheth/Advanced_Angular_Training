import { NgModule } from '@angular/core';
import { HxaLib1Component } from './hxa-lib1.component';



@NgModule({
  declarations: [HxaLib1Component],
  imports: [
  ],
  exports: [HxaLib1Component]
})
export class HxaLib1Module { }
