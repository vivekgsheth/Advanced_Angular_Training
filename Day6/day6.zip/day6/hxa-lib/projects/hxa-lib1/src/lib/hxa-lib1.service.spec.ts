import { TestBed } from '@angular/core/testing';

import { HxaLib1Service } from './hxa-lib1.service';

describe('HxaLib1Service', () => {
  let service: HxaLib1Service;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(HxaLib1Service);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
