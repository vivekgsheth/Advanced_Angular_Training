import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HxaLib1Component } from './hxa-lib1.component';

describe('HxaLib1Component', () => {
  let component: HxaLib1Component;
  let fixture: ComponentFixture<HxaLib1Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HxaLib1Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(HxaLib1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
