import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { throwError } from 'rxjs';
import {catchError, map, shareReplay, tap} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AppService {

  url ="http://localhost:8090/api/orders";
  constructor(private http : HttpClient) { }

  
  getOrders(){
    return this.http.get<any[]>(this.url).pipe(
      tap((data)=>{
        console.log(data)
      }),
      catchError(err=>this.handleError(err))
    )
  }

  allOrders$ = this.http.get<any[]>(this.url).pipe(
    map(orders =>
      orders.map(
        order =>
          ({
            ...order,
            owner: `${order.Title}@${order.City}`
          } )
      )
    ),
    catchError(err => {
      console.error(err);
      return throwError(err);
    }),
    shareReplay(1)
  );

  handleError(err:any){
    return err; 
  }
}
