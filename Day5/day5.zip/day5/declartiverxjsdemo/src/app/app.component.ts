import { Component, OnDestroy, OnInit } from '@angular/core';
import { EMPTY, Subscription } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { AppService } from './app.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, OnDestroy {
  title = 'declartiverxjsdemo';
  orders : any; 
  appservicesubscription$ : Subscription; 
  orders$:any; 
  error = false; 
  constructor(private app : AppService){

  }
  ngOnInit(){
    this.appservicesubscription$ = this.app.getOrders().subscribe(
      (data)=>{
        this.orders = data; 
      },
      error => {console.log(error)},
      ()=>{console.log('complete')}
    )

    this.orders$ = this.app.allOrders$.pipe(
      catchError(err => {
        this.error = true;
        return EMPTY;
      })
    )

  }
  ngOnDestroy(){
     this.appservicesubscription$.unsubscribe();
  }
}
