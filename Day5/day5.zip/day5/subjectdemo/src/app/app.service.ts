import { Injectable } from '@angular/core';
import { AsyncSubject, BehaviorSubject, Observable, ReplaySubject, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AppService {

  counter = 0; 
  //private count$ : Subject<number>;
  //private count$ : BehaviorSubject<number>;
 // private count$ : AsyncSubject<number>;
  //private count$ : ReplaySubject<number>;
  private count$ : ReplaySubject<number>;
  count: Observable<number>; 
  constructor() { 
   this.nextData();

  }

  nextData(){
  //  this.count$ = new Subject<number>();
  //  this.count$ = new BehaviorSubject<number>(0);
   //  this.count$ = new AsyncSubject<number>();
   this.count$ = new ReplaySubject<number>();
    this.count = this.count$.asObservable();
    setInterval(()=>{
     this.counter = this.counter + 1; 
     if(this.counter >=20){
       this.count$.complete();
     }
     this.count$.next(this.counter);
    },1000)
  }
}
