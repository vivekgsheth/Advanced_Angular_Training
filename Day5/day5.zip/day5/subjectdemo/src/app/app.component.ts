import { Component, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
import { AppService } from './app.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnDestroy {
  title = 'Different Types of Subject Dempo in RxJS';
  observer1$: Subscription;
  observer2$: Subscription;
  observer3$: Subscription;
  observer1: number[] = [];
  observer2: number[] = [];
  observer3: number[] = [];
  showObserver1 = false;
  showObserver2 = false;
  showObserver3 = false;

  constructor(private appservice: AppService) {

  }

  subscribe1() {

    this.observer1$ = this.appservice.count.subscribe(
      (data) => {
        this.observer1.push(data)
      },
      (error) => { console.log(error) },
      () => {
        console.log('complete ');
        this.showObserver1 = true;
      }
    )

  }

  subscribe2() {

    this.observer2$ = this.appservice.count.subscribe(
      (data) => {
        this.observer2.push(data)
      },
      (error) => { console.log(error) },
      () => {
        console.log('complete ');
        this.showObserver2 = true;
      }
    )
  }

  subscribe3() {

    this.observer3$ = this.appservice.count.subscribe(
      (data) => {
        this.observer3.push(data)
      },
      (error) => { console.log(error) },
      () => {
        console.log('complete ');
        this.showObserver3 = true;
      }
    )

  }

  ngOnDestroy() {
    this.observer1$.unsubscribe();
    this.observer2$.unsubscribe();
    this.observer3$.unsubscribe();
  }
}
