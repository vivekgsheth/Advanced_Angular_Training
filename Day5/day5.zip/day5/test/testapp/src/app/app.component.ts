import { Component, OnInit } from '@angular/core';
import { EMPTY, Subscription } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { AppService } from './app.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'testapp';
  orders : any; 
  appservicesubscription$ : Subscription; 
  orders$:any; 
  error = false; 

  constructor(private appservice : AppService){

  }
  ngOnInit(){
     this.appservicesubscription$ = this.appservice.getOrders().subscribe(data=>{
       console.log(data);
       this.orders = data; 
     })

     this.orders$ = this.appservice.allOrders$.pipe(
      //Our error thrown from the service bubbles to the component where we handle
      //it. I'm just simply setting a property to true
      //You have to return an Observable so I just return a empty observable that completes
            catchError(err => {
              this.error = true;
              return EMPTY;
            })
          );

          this.appservice.selectedOrderData$.subscribe(data=>{
            console.log(data);
          })
  }


}
