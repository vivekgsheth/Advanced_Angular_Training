import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, combineLatest } from 'rxjs';
import { throwError } from 'rxjs/internal/observable/throwError';
import {catchError, map, shareReplay, tap} from 'rxjs/operators';
import {Observable} from 'rxjs'
@Injectable({
  providedIn: 'root'
})
export class AppService {

  url ="http://localhost:8090/api/orders";
  constructor(private http: HttpClient) { 

  }

  private selectedOrderSubject = new BehaviorSubject<number>(1);
  selectedOrderAction$ = this.selectedOrderSubject.asObservable();
  onSelectedUser(id:any) {
    this.selectedOrderSubject.next(id);
  }

  

  getOrders() {
    return this.http.get<any[]>(this.url).pipe(
        tap((data)=>{console.log(data)}),
        catchError(err => this.handleError(err)))
  }

  allOrders$ = this.http.get<any[]>(this.url).pipe(
    map(orders =>
      orders.map(
        order =>
          ({
            ...order,
            owner: `${order.Title}@${order.City}`
          } )
      )
    ),
    catchError(err => {
      console.error(err);
      return throwError(err);
    }),
    shareReplay(1)
  );

  handleError(error:any){
   return  error; 
  }

  selectedOrderData$: Observable<any> = combineLatest([
    this.allOrders$,
    this.selectedOrderAction$
  ]).pipe(
    map(([allOrders, selectedId]) => allOrders.find(u => u.Id === selectedId))
  );

}
