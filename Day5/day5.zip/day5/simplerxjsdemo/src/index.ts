// console.log("hello");

import { BehaviorSubject, Observable, Subject } from "rxjs";

// var Cat = {
//     name :'foo',
//     age: 9 
// }

// let catAge = Cat.age; 

// updateCatDom();

// document.getElementById('btn1').addEventListener("click",function(){
//     updateCatAge();
//     updateCatDom();
// })


// document.getElementById('btn2').addEventListener("click",function(){
//     updateCatAge();
//     updateCatDom();
// })

// function updateCatAge(){
//     Cat.age = Cat.age + 1; 
//     catAge = Cat.age;
//     console.log(catAge);
// }

// function updateCatDom(){

//     document.getElementById("cat1").innerHTML =  catAge.toString();
//     document.getElementById("cat2").innerHTML =  catAge.toString();
// }

// RxJS demo 
// var Cat = {
//     name :'foo',
//     age: 9 
// }

// let catAge$ = new BehaviorSubject<number>(Cat.age);

// catAge$.subscribe(data=>{
//     document.getElementById("cat1").innerHTML =  data.toString()
//     document.getElementById("cat2").innerHTML =  data.toString();
// })

// document.getElementById('btn1').addEventListener("click",function(){
//     updateCatAge();
// })

// document.getElementById('btn2').addEventListener("click",function(){
//     updateCatAge();
// })

// function updateCatAge(){
//     Cat.age = Cat.age + 1; 
//     catAge$.next(Cat.age);
// }

// let observable = new Observable(subscriber =>{
//     let a = 99; 
//     subscriber.next(99);
//     subscriber.next(190);
//     if(a== 101){
//         subscriber.error();
//     }
//     subscriber.next(12);
//     setTimeout(() => {
//         subscriber.next(800);
//         subscriber.complete();
//     },1000);
// })

// let abc = {
//     next: (data:any) =>{console.log(data)},
//     error: (err:any)=>{console.log(err)},
//     complete:()=>{console.log('complete')}
// }

// let foo = observable.subscribe(abc); 
// foo.unsubscribe();

// observable.subscribe(
//     data=>{console.log(data)},
//     null,
//     ()=>{console.log('error')}
// });


function countsubscribe(subscriber:any){
    let count = 0;
     setInterval(()=>{
      count = count + 1; 
      subscriber.next(count)
      if(count == 10){
          subscriber.complete();
      }
     },1000);
  }
  const countObservable  = new Observable(countsubscribe);

  countObservable.subscribe(
      (data)=>{console.log('subsriber 1- ' , data)},
      null,
      ()=>console.log('complete observer1')
  )

  const observer2 = {
      next : (data:any)=>{console.log('subsriber 2 - ', data)},
      error : (err:any)=>{console.log(err)},
      complete :()=> {console.log('complete')}
  }

  setTimeout(()=>{
      countObservable.subscribe(observer2);
  },5000)

  












