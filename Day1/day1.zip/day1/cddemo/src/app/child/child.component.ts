// import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Input, OnChanges, OnDestroy, OnInit } from '@angular/core';
// import { Observable, Subscription } from 'rxjs';

// @Component({
//   selector: 'app-child',
//   templateUrl: './child.component.html',
//   styleUrls: ['./child.component.css'],
//   changeDetection:ChangeDetectionStrategy.OnPush
// })
// export class ChildComponent implements OnInit, OnDestroy {

//   count : any; 
//   @Input() Counter : Observable<any>; 
//   countSubscription : Subscription; 
//   constructor(private cd : ChangeDetectorRef) { }
//   ngOnInit(): void {
//     this.countSubscription = this.Counter.subscribe(data=>{
//       this.count = data.count; 
// run some business logic 
//       console.log(this.count);
//        this.cd.markForCheck();
//       // this.cd.detectChanges();
//     })

//   }
//    ngOnDestroy():void{
//      this.countSubscription.unsubscribe();
//    }
// }


// import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Input, OnChanges, OnDestroy, OnInit } from '@angular/core';
// import { Observable, Subscription } from 'rxjs';

// @Component({
//   selector: 'app-child',
//   templateUrl: './child.component.html',
//   styleUrls: ['./child.component.css'],
//   changeDetection:ChangeDetectionStrategy.OnPush
// })
// export class ChildComponent implements OnInit, OnDestroy {
//   @Input() Counter : Observable<any>;

//   constructor(private cd : ChangeDetectorRef) { }
//   ngOnInit(): void {
//   }
//    ngOnDestroy():void{
//    }
// }

import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Input, OnChanges, OnDestroy, OnInit } from '@angular/core';
import { Observable, Subscription } from 'rxjs';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css'],
  changeDetection: ChangeDetectionStrategy.Default
})
export class ChildComponent implements OnInit, OnDestroy {

  @Input() Counter: any;

  constructor(private cd: ChangeDetectorRef) {

    this.cd.detach();
   // this.cd.checkNoChanges();
  }

  reattach(){
   // this.cd.reattach();
   this.cd.detectChanges();
  }
  ngOnInit(): void {
  }
  ngOnDestroy(): void {
  }
}


