// import { ChangeDetectorRef, Component, OnInit } from '@angular/core';

// @Component({
//   selector: 'app-root',
//   templateUrl: './app.component.html',
//   styleUrls: ['./app.component.css']
// })
// export class AppComponent implements OnInit  {
  
//   Counter = {
//     count : 1
//   }
//   constructor(){
    
//   }
//   ngOnInit(){
   
//   }

//   incCount(): void {
//      this.Counter.count = this.Counter.count + 1; 
//     // console.log(this.Counter.count);
//     // this.Counter = {
//     //   count: this.Counter.count + 1 
//     // }
//     // this.Counter = {
//     //   count: this.Counter.count 
//     // }
//   }
// }


// import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
// import { BehaviorSubject } from 'rxjs';

// @Component({
//   selector: 'app-root',
//   templateUrl: './app.component.html',
//   styleUrls: ['./app.component.css']
// })
// export class AppComponent implements OnInit  {
  
//   _count = 1; 
//   Counter : any; 
//   constructor(){
    
//   }
//   ngOnInit(){
//     this.Counter = new BehaviorSubject({
//       count: 0 
//     })
//   }

//   incCount(): void {
//    this.Counter.next({
//      count: ++this._count
//    })
//   }
// }


import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit  {
  

   Counter = {
    count : 1
  }
  constructor(){
    
  }
  ngOnInit(){
    
  }

  incCount(): void {
    this.Counter.count = this.Counter.count + 1; 
  }
}
