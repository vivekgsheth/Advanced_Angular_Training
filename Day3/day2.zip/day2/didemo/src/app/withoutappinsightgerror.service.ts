import { ErrorHandler, Injectable } from "@angular/core";


@Injectable()
export class WithoutAppInsight implements ErrorHandler{

     handleError(error:any){

        console.log("I will handle myself without app insight ");
       
     }
   

}