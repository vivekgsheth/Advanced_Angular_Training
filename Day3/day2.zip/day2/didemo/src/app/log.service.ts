import { Inject, Injectable } from '@angular/core';
import { ApiConfig } from './apiconfig';
import { apiconfigvalue } from './apiconfig.value';

@Injectable({
  providedIn:'any'
})
export class LogService {
  private static count = 0; 
  constructor(@Inject(apiconfigvalue) private config: ApiConfig) { 
    LogService.count = LogService.count + 1; 
    console.log('Number of Objects created : ' , LogService.count);

  }
  sayHello(name:string): string{
     return "Hello - " + name; 
  }

  getValue(){
    return this.config;
  }
  
}


