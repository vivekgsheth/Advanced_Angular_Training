export interface ApiConfig{
    EndPoint: string; 
    Token : string; 
}