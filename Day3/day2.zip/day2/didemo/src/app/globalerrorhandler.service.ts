import { ErrorHandler, Injectable } from "@angular/core";


@Injectable()
export class GlobalErrorHandler implements ErrorHandler{

     handleError(error:any){
        // busines logic
        // find the url of page 
        // log to the db 
        console.log("I will handle myself");
      //  throw error; 
       
     }

    //  handleError(error){
    //      // npm install stacktrace --save 
    //     console.log("I will handle error myself");
    //     //throw error;
    //     const message = error.message ? error.message : error.toString();
    //     const url ="abc";
     
    //     StackTrace.fromError(error).then(s=>{
    //         const stackstring = s.splice(0,20).map(function(r){
    //             return r.toString();
    //         }).join('\n');
    //       // send stackstring to server 
    //         console.log({message,url,stack:stackstring});
    //     })  


}