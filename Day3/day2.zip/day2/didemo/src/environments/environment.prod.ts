export const environment = {
  production: true,
  EndPoint :'abcprod.com'
};
