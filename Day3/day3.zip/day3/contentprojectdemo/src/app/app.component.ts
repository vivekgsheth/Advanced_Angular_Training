import { Component } from '@angular/core';
import { User } from './user';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'contentprojectdemo';
  logingeader = "Login 99";
  rememberMe : boolean = false; 

  loginUser(user:User){
    console.log('Login - ', user, this.rememberMe);
  }

  createUser(user:User){
     console.log('sign up -', user);
  }

  rememberUser(remember: boolean){
    this.rememberMe = remember; 

  }
}
