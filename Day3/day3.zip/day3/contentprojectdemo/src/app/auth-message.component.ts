import {Component} from '@angular/core';
@Component({
    selector:'auth-message',
    template:`you will be logged in for {{days}} days`
})
export class AuthMessageComponent {
    days: number = 10; 
}
