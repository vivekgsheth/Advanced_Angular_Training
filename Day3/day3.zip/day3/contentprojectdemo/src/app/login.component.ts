import { OnInit } from "@angular/core";
import { FormBuilder, FormGroup } from "@angular/forms";

export class LoginComponent implements OnInit{

    loginForm: FormGroup; 
    constructor(private fb: FormBuilder){
        
    }

    ngOnInit(){
    //    this.loginForm = this.fb.group(
    //        email=[],
    //        password= [],
    //        conformpassword=[]
    //    )
    }
}