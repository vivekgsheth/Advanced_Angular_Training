import { Component, EventEmitter, Output } from '@angular/core';

@Component({
    selector: 'app-auth-remember',
    template: `
    <label>
    <input type="checkbox" (change)="onChecked($event)"/>
    keep me logged in 
    </label>`
})
export class AuthRememberComponent {

    @Output() checked: EventEmitter<boolean> = new EventEmitter<boolean>();

    onChecked(value: any ) {
        const b = value.target.checked; 
        this.checked.emit(b);
    }

}
