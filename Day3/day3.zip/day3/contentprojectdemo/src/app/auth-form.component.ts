import { AfterContentInit, AfterViewChecked, AfterViewInit, ChangeDetectorRef, Component, ContentChild, EventEmitter, OnInit, Output, ViewChild } from "@angular/core";
import { AuthMessageComponent } from "./auth-message.component";
import { AuthRememberComponent } from "./auth-remember.component";
import { User } from "./user";

const template = `
<div>
    <form (ngSubmit)="onSubmit(form.value)" #form="ngForm">
     <ng-content select="h3"></ng-content>
        <label>
            Email address
            <input type="email" name="email" ngModel>
        </label>
        <label>
            Password
            <input type="password" name="password" ngModel>
        </label>
        <ng-content select="button"></ng-content>
       <ng-content select="app-auth-remember"></ng-content>
       <auth-message [style.display]="(showMessage ? 'inherit':'none')">
       </auth-message>
    </form>
</div>
`
@Component({
    selector:'app-auth-form',
    template:template 
})
export class AuthFormComponent implements OnInit, AfterContentInit, AfterViewInit, AfterViewChecked {
    @Output() submitted: EventEmitter<User> = new EventEmitter<User>();
    @ContentChild(AuthRememberComponent) remember : AuthRememberComponent;
    @ViewChild(AuthMessageComponent) message : AuthMessageComponent; 
    showMessage: boolean = false; 
    constructor(private cd: ChangeDetectorRef){

    }
    onSubmit(value: User ){
      //console.log(value);
      this.submitted.emit(value);
    }

    ngAfterViewChecked(){
  
    }
    ngOnInit(){
        // console.log(this.remember);
        // if(this.remember == true){
        //     this.showMessage = true; 
        // }
       // console.log(this.message);
    }

    ngAfterViewInit(){
        console.log(this.message);
        this.message.days = 45; 
        this.cd.markForCheck();
    }

    ngAfterContentInit(){
        if(this.remember !== undefined){
          //  console.log(this.remember);
            this.remember.checked.subscribe(data=>{
                this.showMessage = data; 
            })
        }
        
    }

}