import { Component, ComponentFactoryResolver, ViewChild, ViewContainerRef } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'dynamicloading';
  greetmessage = "hello HxA";
  greetShow = false;
  abc = "India";
  @ViewChild('greettemp',{read:ViewContainerRef}) private greetviewcontainerref: ViewContainerRef

  constructor(private vcref: ViewContainerRef, private cfr: ComponentFactoryResolver) {

  }

  sendmessage(message: any) {
    console.log(message);
  }

  // async loadGreetComponent(){

  //     const {GreetComponent} = await import('./greet.component');
  //     let greetcomp = this.vcref.createComponent(this.cfr.resolveComponentFactory(GreetComponent));
  //     greetcomp.instance.greetMessage = "Hello Lazy Loaded";
  //     greetcomp.instance.sendMessageEvent.subscribe(data=>{
  //       console.log(data);
  //     })

  // }

  // loadGreetComponent() {
  //   this.vcref.clear();
  //   import('./greet.component').then(({ GreetComponent }) => {
  //     let greetcomp = this.vcref.createComponent(this.cfr.resolveComponentFactory(GreetComponent));
  //     greetcomp.instance.greetMessage = "Hello Lazy Loaded then";
  //     greetcomp.instance.sendMessageEvent.subscribe(data => {
  //       console.log(data);
  //     })
  //   }
  //   )

  // }

    async loadGreetComponent(){
      this.greetviewcontainerref.clear();
      const {GreetComponent} = await import('./greet.component');
      let greetcomp = this.greetviewcontainerref.createComponent(this.cfr.resolveComponentFactory(GreetComponent));
      greetcomp.instance.greetMessage = "Hello Lazy Loaded";
      greetcomp.instance.sendMessageEvent.subscribe(data=>{
        console.log(data);
      })

  }
}
