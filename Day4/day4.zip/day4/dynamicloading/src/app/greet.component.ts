
import { Component, EventEmitter, Input, NgModule, OnInit, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';

const template=  `
  <h1>Greetings </h1>
  <h2>{{greetMessage}}</h2>
  <button (click)='greet()'>sayHello</button>
  <input type='text' [(ngModel)]='message' />
  <h3>Hello {{message}}</h3>
  `

@Component({
  selector: 'app-greet',
  template : template,
  styleUrls: ['./greet.component.css']
})
export class GreetComponent implements OnInit {

  @Input() greetMessage: string;
  @Output() sendMessageEvent = new EventEmitter();
  message : string = "dhananjay";

  constructor() { }
  ngOnInit(): void {
    console.log('hello');
  }

  greet(): void {
    this.sendMessageEvent.emit('Hello From Greet Component');

  }

}

@NgModule({
   declarations:[GreetComponent],
  imports:[FormsModule]
})
class GreetModule{

}
