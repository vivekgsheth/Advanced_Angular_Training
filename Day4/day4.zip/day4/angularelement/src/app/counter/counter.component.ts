import { Component, EventEmitter, Input, OnInit, Output, ViewEncapsulation } from '@angular/core';


@Component({
  selector: 'app-counter',
  templateUrl: './counter.component.html',
  styleUrls: ['./counter.component.css'],
  encapsulation: ViewEncapsulation.ShadowDom
})
export class CounterComponent implements OnInit {

  @Input() count: number; 
  @Output() incevent = new EventEmitter();
  @Output() decevent = new EventEmitter();
  
  constructor() { }

  ngOnInit(): void {
  }

  inc(){

    this.count = ++this.count; 
    this.incevent.emit(this.count);
  }

  dec(){
    this.count = --this.count; 
    this.decevent.emit(this.count);

  }

}
