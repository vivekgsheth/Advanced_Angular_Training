const fs = require('fs-extra');
const concat = require('concat');

(async function build() {
  const files = [
    './dist/angularelement/runtime.js',
    './dist/angularelement/polyfills.js',
    './dist/angularelement/main.js'
  ];

  await fs.ensureDir('elements');
  await concat(files, 'elements/dj-counter.js');
  await fs.copyFile(
    './dist/angularelement/styles.css',
    'elements/styles.css'
  );
})();