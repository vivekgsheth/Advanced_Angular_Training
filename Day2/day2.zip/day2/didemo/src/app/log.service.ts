import { Injectable } from '@angular/core';

@Injectable()
export class LogService {
  private static count = 0; 
  constructor() { 
    LogService.count = LogService.count + 1; 
    console.log('Number of Objects created : ' , LogService.count);

  }
  sayHello(name:string): string{
     return "Hello - " + name; 
  }
  
}


