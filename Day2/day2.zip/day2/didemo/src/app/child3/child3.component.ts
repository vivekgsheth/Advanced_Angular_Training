import { Component, ErrorHandler, OnInit } from '@angular/core';
import { LogupdatedService } from '../logupdated.service';
import { WithoutAppInsight } from '../withoutappinsightgerror.service';

@Component({
  selector: 'app-child3',
  templateUrl: './child3.component.html',
  styleUrls: ['./child3.component.css'],
  providers:[{provide:ErrorHandler,useClass:WithoutAppInsight}]
})
export class Child3Component implements OnInit {

  message : string; 
  constructor(private logservice : LogupdatedService) { }

  ngOnInit(): void {
    this.message = this.logservice.sayHello("Child 3 ");
    
  }

}
