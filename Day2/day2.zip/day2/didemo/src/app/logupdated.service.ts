import { Injectable } from '@angular/core';

@Injectable()
export class LogupdatedService {

  private static count = 0; 
  constructor() { 
    LogupdatedService.count = LogupdatedService.count + 1; 
    console.log('Log Updated Number of Objects created : ' , LogupdatedService.count);

  }

  sayHello(name:string): string{
    return "Updated Hello - " + name; 
 }
}
